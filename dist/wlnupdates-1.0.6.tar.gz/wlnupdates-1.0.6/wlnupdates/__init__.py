__title__ = 'wlnupdates'
__author__ = 'AlphaNeo'
__license__ = 'MIT'
from .wrapper import Wrapper
from .search import Search